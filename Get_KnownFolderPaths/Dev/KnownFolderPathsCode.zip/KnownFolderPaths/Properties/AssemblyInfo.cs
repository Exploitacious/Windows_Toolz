﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyProduct("KnownFolderPaths")]
[assembly: AssemblyTitle("KnownFolderPaths")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: Guid("7fca5ac2-b0b7-4fd2-ae55-752d29366db1")]
